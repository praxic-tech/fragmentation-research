**Table 9. Precedence against adjacency, and a random attacker that is a legal answer to the game.**

| Attacker | F1_J | F1_L | Adjacency F1 | Run fraction | Longest run (frags) | Docs with no intact pair |
|---|---|---|---|---|---|---|
| Headline (46 pools) |  |  |  |  |  |  |
|   One-shot Sonnet | 0.723 | 0.882 | 0.287 | 0.178 | 4.53 | 0.00 |
|   Embedding (post-hoc exploratory) | 0.182 | 0.364 | 0.011 | 0.048 | 1.28 | 5.04 |
|   Memon-inspired | 0.168 | 0.339 | 0.010 | 0.047 | 1.26 | 5.20 |
|   Random, valid 7 groups (size-blind) | 0.077 | 0.154 | 0.004 | 0.043 | 1.13 | 6.13 |
|   Random, valid 7 groups (oracle sizes) | 0.088 | 0.177 | 0.004 | 0.043 | 1.12 | 6.14 |
| Grid (216 units) |  |  |  |  |  |  |
|   One-shot Sonnet | 0.676 | 0.799 | 0.443 | 0.232 | 6.60 | 0.01 |
|   Embedding (post-hoc exploratory) | 0.133 | 0.262 | 0.007 | 0.042 | 1.18 | 5.81 |
|   Memon-inspired | 0.132 | 0.261 | 0.007 | 0.042 | 1.17 | 5.82 |
|   Random, valid 7 groups (size-blind) | 0.072 | 0.144 | 0.004 | 0.040 | 1.13 | 6.13 |
|   Random, valid 7 groups (oracle sizes) | 0.075 | 0.150 | 0.004 | 0.040 | 1.13 | 6.12 |

F1_J scores the FULL within-document precedence relation: every (earlier, later) pair inside a predicted group. Adjacency F1 scores only IMMEDIATE directed pairs. A predicted adjacency spanning two documents is a false positive — no credit is given for the seam between two completed documents, because the output here is a partition rather than one global permutation.
Longest run is the longest stretch of fragments placed consecutively AND in true order, in fragments; a fragment from another document interrupting the sequence breaks the run. Run fraction divides it by the document's fragment count.
Adjacency precision, recall and F1 are equal by construction here and only one is reported: every answer is a valid partition into exactly the known N groups, so the number of predicted adjacent pairs equals the number of true ones (fragments minus groups).
The random rows are VALID answers to the game: a partition into exactly the known N groups. Size-blind deals round-robin and is the matched comparison, because prompt_J states only that records may contain different numbers of fragments. The oracle-size row is given the true per-document sizes, is attacker-favourable, and is not the chance level. Both are means of 1,000 seeded partition draws per pool, with C = K/2 exact over the within-group order.
The analytic one-bucket reference used elsewhere is b_J = 0.149 on the headline pools, but one bucket is not a legal answer to a prompt demanding exactly seven groups: a legal size-blind random answer scores F1_J 0.077. The one-bucket figure therefore overstates the floor by roughly a factor of two, and A_J correspondingly understates the advantage over a legal random attacker.
The non-generative attackers collapse on the adjacency surface in a way the precedence score hides: on the headline pools Memon-inspired scores F1_J 0.169 against a one-bucket 0.149 but adjacency F1 0.010 against a random 0.004, with about five of seven documents returning no correct adjacency at all.
