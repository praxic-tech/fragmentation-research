**Table 4. Game O (ordering with membership given): One-shot Sonnet against the classical floors.**

| Condition | Docs | Frags/doc | Sonnet τ [95% CI] | Median τ | Pairs correct | Exact | Jaccard-Greedy τ [95% CI] | Jaccard-MST τ [95% CI] |
|---|---|---|---|---|---|---|---|---|
| headline (full length) | 100 | 33.5 | 0.769 [0.735, 0.802] | 0.810 | 0.885 | 0.01 | -0.005 [-0.032, 0.022] | 0.012 [-0.016, 0.041] |
| random / sentence | 30 | 25.2 | 0.935 [0.892, 0.968] | 0.984 | 0.967 | 0.47 | -0.061 [-0.109, -0.012] | -0.049 [-0.091, -0.010] |
| random / clause | 30 | 31.7 | 0.905 [0.852, 0.945] | 0.923 | 0.953 | 0.27 | -0.036 [-0.090, 0.018] | -0.007 [-0.064, 0.052] |
| random / token-window | 30 | 42.9 | 0.909 [0.875, 0.942] | 0.927 | 0.955 | 0.23 | -0.026 [-0.071, 0.019] | 0.024 [-0.015, 0.063] |
| semantic / sentence | 30 | 25.2 | 0.841 [0.792, 0.887] | 0.878 | 0.921 | 0.07 | -0.012 [-0.064, 0.041] | -0.016 [-0.088, 0.059] |
| semantic / clause | 30 | 31.7 | 0.791 [0.725, 0.851] | 0.826 | 0.895 | 0.07 | 0.009 [-0.038, 0.056] | 0.009 [-0.038, 0.059] |
| coherence-sever / clause | 30 | 22.5 | 0.816 [0.745, 0.874] | 0.874 | 0.908 | 0.07 | -0.055 [-0.103, -0.001] | 0.010 [-0.049, 0.073] |
| coherence-sever / token-window | 30 | 42.8 | 0.943 [0.917, 0.967] | 0.979 | 0.972 | 0.23 | 0.007 [-0.035, 0.048] | -0.006 [-0.042, 0.034] |
| subject-verb / sentence | 30 | 41.7 | 0.733 [0.666, 0.794] | 0.777 | 0.866 | 0.03 | -0.018 [-0.055, 0.020] | -0.050 [-0.108, -0.001] |
| subject-verb / clause | 30 | 49.4 | 0.724 [0.652, 0.792] | 0.734 | 0.862 | 0.03 | -0.041 [-0.072, -0.009] | -0.009 [-0.045, 0.027] |

Kendall τ between the returned order and the true order, one τ per document; 95% percentile-bootstrap CIs over documents. Random ordering has expectation τ = 0. Pairs correct = (1 + τ)/2. Exact = fraction of documents ordered perfectly.
Jaccard-Greedy / Jaccard-MST are the classical word-bigram Jaccard orderers with masked labels and shuffled, truth-independent tie-breaking (D1); they are not Memon implementations. Their pre-correction values (τ +0.32 / +0.70) were an id-order leak and are superseded. Every unit completed (0 RBNC).
